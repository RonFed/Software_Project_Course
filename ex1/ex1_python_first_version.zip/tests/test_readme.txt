1. k=3, max_iter = 600
2. k=7, max_iter = not provided
3. k=15, max_iter = 300